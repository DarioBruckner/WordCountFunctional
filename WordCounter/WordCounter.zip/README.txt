Start the WordCounter.exe and set the filepath and fileextension. IMPORTANT set the fileextension without a dot
	WordCounter.exe Path\to\directory txt
Bruckner Dario if20b023
Fohleitner Dominik if20b178